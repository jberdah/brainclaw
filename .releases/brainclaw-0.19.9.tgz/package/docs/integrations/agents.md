# Agent Integration Principles

## Core reality

No agent should be assumed to obey a single instruction perfectly every time.

That means brainclaw integration should not rely on only one mechanism such as:

- a single instruction file
- a single skill
- a single startup command

## Better approach

Use multiple points of contact:

- lightweight system instructions
- project-specific context retrieval through MCP when available
- prompt-ready generated context
- native agent files for local reminders
- MCP tools for dynamic state
- board and status views
- workflow reminders around plans, claims, and handoffs

## Surface hierarchy

The default order is:

1. MCP for live state
2. native agent files for local workflow guidance
3. readable files as fallback
4. CLI for setup, operator tasks, scripting, and fallback workflows

This keeps dynamic state dynamic instead of trying to encode it permanently into static instructions.

## System instructions vs project instructions

Keep these separate.

### System instructions
How the agent should use brainclaw.

Examples:

- check workspace memory before significant changes
- prefer MCP over manual CLI calls when MCP is available
- bootstrap if the workspace is not initialized and the workflow allows it
- respect file claims
- update shared plan status when appropriate

### Project instructions
What is true for the current workspace.

Examples:

- active constraints
- recent decisions
- known traps
- current handoffs
- relevant plan context

## Setting up agent integration

### Automatic detection

```bash
brainclaw init
```

`setup` and `init` write the appropriate local agent config files for the detected integrations. Workspace-local generated files are also added to `.gitignore` automatically so agent-specific config does not pollute Git status.

### Manual per-agent setup

```bash
brainclaw enable-agent claude-code
brainclaw enable-agent cursor
brainclaw enable-agent windsurf
brainclaw enable-agent opencode
brainclaw enable-agent antigravity
```

### Export to a specific format

```bash
brainclaw export --format claude-md --write
brainclaw export --format cursor-rules --write
brainclaw export --format agents-md --write   # Codex, OpenCode
brainclaw export --format gemini-md --write   # Antigravity / Gemini CLI
brainclaw export --format claude-md --write --shared   # only if you want the main instruction file versioned
```

`--detect` auto-selects formats based on files found in the workspace:

```bash
brainclaw export --detect --write
```

By default, `--write` treats generated workspace files as local setup and adds them to `.gitignore`. `--shared` only keeps the main exported instruction file versionable; companion MCP/settings files remain local. OpenCode also gets a workspace MCP config in `opencode.json`. Antigravity/Gemini CLI gets a machine-local MCP config in `.gemini/antigravity/mcp_config.json` when `HOME` is available.

If a repo already contains tracked local agent files from an older setup, `brainclaw session-start` warns at the beginning of work and `brainclaw doctor --fix-agent-ignore` can repair the missing `.gitignore` entries. Tracked files still need to be untracked manually with Git after the ignore rules are in place.

## MCP server workflow

The brainclaw MCP server exposes the dynamic Brainclaw workflow directly. For capable agents, this is the nominal runtime path.

### Starting the MCP server

```bash
brainclaw mcp
```

Most agents pick this up via their MCP config file (`.mcp.json`, `~/.cursor/mcp.json`, etc.). brainclaw writes these during `init`.

### Available MCP tools

| Tool | Description |
|------|-------------|
| `bclaw_get_context` | Full workspace context (constraints, decisions, traps, plans, handoffs) |
| `bclaw_get_agent_board` | Live plan + claim board |
| `bclaw_session_start` | Start an agent session (registers identity) |
| `bclaw_session_end` | End session, optionally auto-release claims |
| `bclaw_claim` | Claim a file scope |
| `bclaw_release_claim` | Release a claim |
| `bclaw_create_candidate` | Create a plan item |
| `bclaw_accept` / `bclaw_reject` | Accept or reject a plan candidate |
| `bclaw_write_note` | Write a runtime note |
| `bclaw_search` | Search memory entries |
| `bclaw_read_handoff` | Read a handoff document |
| `bclaw_bootstrap` | Initialize the workspace if not already done |
| `bclaw_get_execution_context` | Get execution context (identity, claims, active plans) |

## Session lifecycle

### Starting a session

```bash
brainclaw session-start --agent my-agent --model claude-opus-4-5
```

This registers the agent's identity and optionally records the model being used. Other agents can see active sessions in `list-claims` and `board`.

### During the session

For MCP-capable agents, prefer the MCP equivalents of these actions. The CLI examples below are the operator and fallback form of the same lifecycle.

```bash
brainclaw context --json        # load fresh project state
brainclaw claim list            # check for conflicts
brainclaw claim create "desc" --scope src/feature/
brainclaw plan create "implement X" --estimate 60
brainclaw plan update <id> --status in_progress
```

### Ending the session

```bash
brainclaw session-end --auto-release
```

This releases all active claims held by the current agent and updates plan statuses.

## Generated files are local-only

Agent config files generated by brainclaw — `CLAUDE.md`, `AGENTS.md`, `GEMINI.md`, `.cursor/rules/brainclaw.md`, `.windsurfrules`, `.github/copilot-instructions.md` — are **not committed to Git**.

Each developer regenerates them locally from their own `.brainclaw/` store:

```bash
brainclaw export --detect --write
```

This ensures:
- no private project notes leak into the shared repo
- each developer's local agent sees the right instructions for their setup
- instructions stay in sync with the current brainclaw store, not a stale committed version

brainclaw adds all generated files to `.gitignore` automatically during `init`.

## Goal

The goal is not perfect enforcement.
The goal is to make brainclaw the natural path for fresh workspace context and coordination.
