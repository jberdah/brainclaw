Load brainclaw project memory and prepare for coordinated work.

Steps:
1. Run `brainclaw context --json` — load constraints, decisions, traps, plans, handoffs
2. Run `brainclaw list-claims` — check what files other agents have claimed
3. Before editing any file, run `brainclaw claim "<description>" --scope <path>`
4. Before finishing, run `brainclaw session-end --auto-release`
